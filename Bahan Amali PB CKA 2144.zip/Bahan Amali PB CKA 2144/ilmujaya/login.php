<?php
//Lengkapkan kod php untuk menghubungkan fail




if(isset($_POST['login'])){
    //Lengkapkan kod untuk akses ke database






    
    
    if(mysqli_num_rows($query) > 0){
        $_SESSION['login'] = true;
        header("Location: index.php");
    } else {
        echo "Login gagal!";
    }
}
?>

<link rel="stylesheet" href="style.css">
<div class="container">
<h2>IlmuJaya Bookstore - Login</h2>
<form method="POST">
ID Staf:<br>
<input type="text" name="idstaf"><br>
Kata Laluan:<br>
<input type="password" name="password"><br>
<button type="submit" name="login">Login</button>
</form>
</div>
