<?php
//Lengkapkan kod php untuk menghubungkan fail


if(!isset($_SESSION['login'])){
    header("Location: login.php");
}

$result = mysqli_query($conn, "SELECT * FROM ");
$count = mysqli_num_rows($result);
?>

<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Senarai Buku</h2>
<a href="add.php">Tambah Buku</a>
<table>
<tr>
<th>Bil</th>
<th>Tajuk</th>
<th>Harga (RM)</th>
<th>Tindakan</th>
</tr>

<?php 
//Lengkapkan kod php untuk papar data
$no = 1;  
while($row = mysqli_fetch_assoc($result)) 
  { ?>
<tr>
<td><?php echo $no++; ?></td>
<td>
<td>
<td>
<a href="edit.php?id=<?php echo $row['']; ?>">Edit</a>
<a href="delete.php?id=<?php echo $row['']; ?>">Hapus</a>
</td>  
</tr>
<?php } ?>

</table>

<p>Jumlah Buku Direkodkan: <?php echo $count; ?></p>
<a href="logout.php">Logout</a>
</div>
