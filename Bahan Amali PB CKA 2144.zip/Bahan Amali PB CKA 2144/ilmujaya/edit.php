<?php
//Lengkapkan kod php untuk menghubungkan fail


$id = 
$result = 
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update'])){
    //Lengkapkan kod php untuk edit/kemaskini data





    
}
?>

<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Edit Buku</h2>
<form method="POST">
Tajuk Buku:<br>
<input type="text" name="tajuk" value="<?php echo $row['tajuk']; ?>"><br>
Harga:<br>
<input type="text" name="harga" value="<?php echo $row['harga']; ?>"><br>
<button type="submit" name="update">Update</button>
</form>
</div>
