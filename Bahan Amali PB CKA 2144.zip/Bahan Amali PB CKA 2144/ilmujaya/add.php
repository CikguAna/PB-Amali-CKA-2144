<?php
//lengkapkan kod untuk tambah data





?>

<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Tambah Buku</h2>
<form method="POST">
Tajuk Buku:<br>
<input type="text" name="tajuk" value=""><br>
Harga:<br>
<input type="text" name="harga" value=""><br>
<button type="submit" name="add">Add</button>
</form>
</div>
